<?php
require '../koneksi.php';

session_start();  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  // Tangkap data dari formulir ulasan
  $username = $_SESSION['username'];
  $isi_ulasan = $_POST['isi_ulasan'];
  $id_rumah = $_POST['id_rumah'];

  // Validasi data (tambahkan logika validasi sesuai kebutuhan)

  // Insert ulasan ke dalam database
  $query = "INSERT INTO tb_ulasan (isi_ulasan, id_rumah, username) VALUES ('$isi_ulasan', $id_rumah, '$username')";
  $result = mysqli_query($conn, $query);

  // Cek apakah query berhasil dijalankan
  if ($result) {
      echo "Ulasan berhasil ditambahkan!";
  } else {
      echo "Error: " . mysqli_error($conn);
  }

  // Redirect ke halaman ulasan.php
  header("Location: ../ulasan.php?id_rumah=$id_rumah");
  exit;
}

?>
