<?php
require '../koneksi.php';

$propertyData = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $propertyId = $_POST['property_id'];
    $newLokasiRumah = mysqli_real_escape_string($conn, $_POST['new_lokasi_rumah']);
    $newHargaRumah = mysqli_real_escape_string($conn, $_POST['new_harga_rumah']);
  
    $newFotoRumahName = $_FILES['new_foto_rumah']['name'];
    $newFotoRumahTmp = $_FILES['new_foto_rumah']['tmp_name'];
    $newFotoRumahDestination = "foto_rumah/" . $newFotoRumahName;
  
    if (!empty($newFotoRumahName)) {
        move_uploaded_file($newFotoRumahTmp, $newFotoRumahDestination);
  
        $update_query = "UPDATE tb_rumah SET lokasi_rumah = '$newLokasiRumah', harga_rumah = '$newHargaRumah', foto_rumah = '$newFotoRumahName' WHERE id_rumah = '$propertyId'";
    } else {
        $update_query = "UPDATE tb_rumah SET lokasi_rumah = '$newLokasiRumah', harga_rumah = '$newHargaRumah' WHERE id_rumah = '$propertyId'";
    }
  
    $result = mysqli_query($conn, $update_query);
  
    if ($result) {
        $message = "Data rumah berhasil diupdate!";
        header('location: ../admin_panel.php');
    } else {
        $message = "Error: " . mysqli_error($conn);
    }

}

?>