<?php
require '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Ensure that the property ID is provided in the URL
    if (isset($_GET['id'])) {
        $propertyId = $_GET['id'];

        // Select the photo filename before deleting the property
        $select_query = "SELECT foto_rumah FROM tb_rumah WHERE id_rumah = '$propertyId'";
        $result = mysqli_query($conn, $select_query);

        if ($result && mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);

            // Delete the property from the database
            $delete_query = "DELETE FROM tb_rumah WHERE id_rumah = '$propertyId'";
            $delete_result = mysqli_query($conn, $delete_query);

            if ($delete_result) {
                // Delete the associated photo from the server
                $photoFileName = $row['foto_rumah'];
                $photoPath = "foto_rumah/" . $photoFileName;

                if (file_exists($photoPath)) {
                    unlink($photoPath);
                }

                header("Location: ../admin_panel.php");
                exit();
            } else {
                // Handle deletion error
                echo "Error: " . mysqli_error($conn);
            }
        } else {
            // Handle property not found
            echo "Property not found";
        }
    } else {
        // Handle missing property ID
        echo "Property ID not provided";
    }
} else {
    // Handle invalid request method
    echo "Invalid request method";
}
?>
