<?php
require('../koneksi.php');

session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $role = 'user';

    $checkUsernameQuery = "SELECT * FROM tb_akun WHERE username = '$username'";
    $checkUsernameResult = mysqli_query($conn, $checkUsernameQuery);

    if (mysqli_num_rows($checkUsernameResult) == 0) {
        $insertQuery = "INSERT INTO tb_akun (username, password, role) VALUES ('$username', '$hashedPassword', '$role')";
        $insertResult = mysqli_query($conn, $insertQuery);

        if ($insertResult) {
            header('Location: ../login.php');
            exit();
        } else {
            header('Location: ../register.php');
            exit();
        }
    } else {
        header('Location: ../register.php');
        exit();
    }
}
?>
