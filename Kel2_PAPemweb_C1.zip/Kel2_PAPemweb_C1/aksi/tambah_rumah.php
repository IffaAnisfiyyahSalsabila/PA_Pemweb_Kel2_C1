<?php
require 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Process the form data when the form is submitted
    $lokasi_rumah = $_POST['lokasi_rumah'];
    $harga_rumah = $_POST['harga_rumah'];

    // File Upload Handling
    $foto_rumah_name = $_FILES['foto_rumah']['name'];
    $foto_rumah_tmp = $_FILES['foto_rumah']['tmp_name'];
    $foto_rumah_destination = "foto_rumah/" . $foto_rumah_name;

    // Move the uploaded file to the desired destination
    move_uploaded_file($foto_rumah_tmp, $foto_rumah_destination);

    // Insert the data into the database
    $insert_query = "INSERT INTO tb_rumah (lokasi_rumah, harga_rumah, foto_rumah) VALUES ('$lokasi_rumah', '$harga_rumah', '$foto_rumah_name')";
    $result = mysqli_query($conn, $insert_query);
}
?>