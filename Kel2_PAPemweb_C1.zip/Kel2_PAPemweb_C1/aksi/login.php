<?php
require '../koneksi.php';

session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $pw = $_POST['password'];

    $getUserQuery = "SELECT * FROM tb_akun WHERE username = '$username'";
    $getUserResult = mysqli_query($conn, $getUserQuery);

    if (mysqli_num_rows($getUserResult) > 0) {
        $user = mysqli_fetch_assoc($getUserResult);

        if (password_verify($pw, $user['password'])) {
            $_SESSION['username'] = $username;
            $_SESSION['role'] = $user['role'];

            if ($_SESSION['role'] == 'user') {
                header('Location: ../lihat_rumah.php');
                exit();
            } else {
                header('Location: ../admin_panel.php');
                exit();
            }
        } else {
            // header('Location: ../login.php');
            echo 'test';
            echo ' ';
            echo $pw;
            echo ' ';
            echo $user['password'];
            // exit();
        }
    } else {
        header('Location: ../login.php');
        exit();
    }
}
?>
