-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2023 at 04:34 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_land_house`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_akun`
--

CREATE TABLE `tb_akun` (
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_akun`
--

INSERT INTO `tb_akun` (`username`, `password`, `role`) VALUES
('aa', '$2y$10$2VYqr9OkU8i.YbKhS3ZHLuKfiYgrpxORjN2vXng02Xr', 'user'),
('abc', '$2y$10$JwUdD5IkWcrsfE3O4/QVJ.nDmrfDPCjGU4SV.9CCcqJ', 'user'),
('admin', 'admin', 'admin'),
('bb', '$2y$10$r8GLROvEfY91RGrJvkVceO8YhRaLz5Wt.qBt.rUEZIC', 'user'),
('ccc', '$2y$10$LYzqr.FdbhPX25i7eeS68uxUu3xWWfidLWrpWTMZqoA', 'user'),
('dd', '$2y$10$jM7XtvA0V.jaIpWcrODlRuVf5oNsIiptZHLbToSwse4', 'user'),
('ddd', '$2y$10$o/8qi2V6bUD6dQMKHPdX6u7mCvAu0ezaHI.InwhTAXG', 'user'),
('ee', '$2y$10$vUGEw8mP7OERM5Henetlzeh4JJtmV5pfoTvWcmHn1km', 'user'),
('farrel', '$2y$10$UMnh0KTr2AraZvbOyhsBSO8.iqaiGjObnCBse2CBAzB', 'user'),
('gg', '$2y$10$qSkO8tJw8KxGTewX1RDeX.tr6h7pwSJWSIwqMMgtgP/', 'user'),
('huda', '$2y$10$WzSpxGFkzP.vL3SRwn/nNOXwWUsA/riK4mwHrW/PZgY', 'user'),
('huda123', '$2y$10$Q/49/CFw1Xunoo/r8wTlzOYUObxRHlwULmLb/mtpl2x', 'user'),
('parel', '$2y$10$eLhUm9FzIWXQcaIi67qtje0G.WH7TAVZXBuOoWWKLbv', 'user'),
('prel', '$2y$10$AWVTH.g7Y1nEV2nFRbhN0OBb4Ib77P78RAX751uJ/h8', 'user'),
('qq', '$2y$10$QwBX70T/lvuVeGoZ9GuEy.oiIwMUfyQkLx6eAWXsLr0', 'user'),
('tt', '$2y$10$sTEEPzSLBiKXgQjh8OKZ6.JehmUur9LGZzxP8uj4jkD', 'user'),
('uu', '$2y$10$r.8UZt62SjzbZxRP/TPqQe0vZFpZUjmD.V2MCOpk1or', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_akun`
--
ALTER TABLE `tb_akun`
  ADD PRIMARY KEY (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
